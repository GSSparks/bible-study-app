# John 3

## 3:16

Perhaps the most quoted verse in scripture. Three movements:

1. **God's motivation** — *love* for the *world* (not Israel alone, but all of humanity). The Greek *agapē* here is not sentimental affection but a determined, self-giving will toward another's good.
2. **God's action** — he *gave* his only Son. The aorist tense signals a completed, once-for-all act. "Only begotten" (*monogenēs*) emphasizes uniqueness, not biological generation.
3. **The condition and its two outcomes** — *whoever believes* (present active participle — ongoing trust, not a one-time decision) does not *perish* but *has* (present tense — already possessed) eternal life.

The verse does not say God loves Christians or the religious; the object is *the world* in its lostness.

## 3:17

A necessary corrective to a misreading of 3:16. The Son's coming was not a judicial mission — the world was already under condemnation (v. 18). He came as the way *out* of it, not as its executor.

The word *condemn* (*krinō* → *katakrinō*) carries the sense of a verdict that determines destiny. That verdict is not what the incarnation introduced; it is what it offered an escape from.

## 3:18

Belief and condemnation are not equal and opposite forces applied externally. Unbelief is self-condemnation: the one who does not believe has already decided against the light (see v. 19). The "already" (*ēdē*) is emphatic — there is no neutral ground.

# John 11

## 11:25

"I *am* the resurrection and the life" — not *I will bring* resurrection, but *I am* it. The "I am" formulation (Greek *egō eimi*) echoes Exodus 3:14 throughout John's Gospel.

The two clauses are distinct:
- **Resurrection** (*anastasis*) addresses those who have died physically — they will live again.
- **Life** addresses those currently living — they will never die in the ultimate sense, even if they die physically.

Martha's grief was real and warranted. Jesus does not dismiss it; he reframes its ultimate horizon.

## 11:35

"Jesus wept." The shortest verse in most translations, and one of the most theologically loaded. The Greek verb (*edakrusen*) implies quiet weeping, distinct from the loud lamentation of the mourners in v. 33.

He knew he was about to raise Lazarus. He wept anyway. Grief over death is not faithlessness; it is the appropriate response to an enemy that was never meant to exist.
