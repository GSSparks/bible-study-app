# Genesis 1

## 1:1

"In the beginning, God created the heavens and the earth." Three things are asserted before anything else is narrated:

1. There *was* a beginning — time is not eternal.
2. God pre-existed it — he is not a product of the cosmos.
3. Creation is the result of an act, not an emanation or a conflict.

The Hebrew *bārāʾ* (create) is used exclusively with God as subject throughout the Old Testament. It does not necessarily imply creation *ex nihilo* from this verse alone, but Genesis 1 as a whole strongly implies it — there is no pre-existing material that God shapes; the formless void of v. 2 is itself part of what comes into being.

## 1:2

The earth was *tōhû wābōhû* — formless and void, a phrase used elsewhere (Jer. 4:23) to describe desolation and ruin. The Spirit *hovering* (*meraḥepet*) over the waters uses the same verb as an eagle hovering over its nest (Deut. 32:11) — active, protective, ready to act.

The darkness is not yet evil here; it is simply the absence of the ordering that follows. Light comes first (v. 3) before any structure, because without light there is no differentiation and thus no creation in any meaningful sense.

# Genesis 3

## 3:15

The *protoevangelium* — the first hint of a redeemer. God addresses the serpent: "I will put enmity between you and the woman, and between your offspring and hers; he will crush your head, and you will strike his heel."

The singular "he" and "his heel" in the second line has been read messianically from ancient times. The Septuagint renders the pronoun as masculine (*autos*), reinforcing the individual referent. Whether or not the original author intended a messianic reading, the New Testament writers saw in the serpent's defeat under Christ its fulfillment (Rom. 16:20; Rev. 12:9).

The wound to the heel is survivable. The wound to the head is not.
